
<!-- ALL-CONTRIBUTORS-BADGE:START - Do not remove or modify this section -->
[![All Contributors](https://img.shields.io/badge/all_contributors-8-orange.svg?style=flat-square)](#contributors-)
<!-- ALL-CONTRIBUTORS-BADGE:END -->

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><a href="https://github.com/emrekiciman"><img src="https://avatars3.githubusercontent.com/u/5982160?v=4?s=100" width="100px;" alt=""/><br /><sub><b>emrekiciman</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=emrekiciman" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/amit-sharma"><img src="https://avatars3.githubusercontent.com/u/1775381?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Amit Sharma</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=amit-sharma" title="Code">💻</a></td>
    <td align="center"><a href="http://adamkelleher.com"><img src="https://avatars0.githubusercontent.com/u/1762368?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Adam Kelleher</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=akelleh" title="Code">💻</a> <a href="#content-akelleh" title="Content">🖋</a></td>
    <td align="center"><a href="https://github.com/Tanmay-Kulkarni101"><img src="https://avatars3.githubusercontent.com/u/17275495?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Tanmay Kulkarni</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=Tanmay-Kulkarni101" title="Code">💻</a> <a href="https://github.com/microsoft/dowhy/commits?author=Tanmay-Kulkarni101" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/vojavocni"><img src="https://avatars.githubusercontent.com/u/40206443?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Aleksandar Jovanovic</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=vojavocni" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/n8sty"><img src="https://avatars.githubusercontent.com/u/2964996?v=4?s=100" width="100px;" alt=""/><br /><sub><b>nate giraldi</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=n8sty" title="Documentation">📖</a> <a href="https://github.com/microsoft/dowhy/commits?author=n8sty" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/yaakx"><img src="https://avatars.githubusercontent.com/u/54352800?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Julen Corral</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=yaakx" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="http://toppare.github.io/"><img src="https://avatars.githubusercontent.com/u/6221127?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Baran Toppare</b></sub></a><br /><a href="https://github.com/microsoft/dowhy/commits?author=toppare" title="Documentation">📖</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

## Contributing Guide

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!

There are multiple ways to contribute to DoWhy. 

You can help us make DoWhy better, 
* Adding a Jupyter notebook that describes the use of DoWhy for solving causal
problems

* Helping implement a new method for any of the four steps of causal analysis:
  model, identify, estimate, refute

* Integrating DoWhy's API with external implementations for any of the four steps, so that external libraries can be called seamlessly from the `identify_effect`, `estimate_effect` or `refute_estimate` methods.
 
* Helping extend the DoWhy API so that we can support new functionality like interpretability of the estimate, counterfactual prediction and more. 

* Helping update the documentation for DoWhy

If you would like to contribute, you can raise a pull request. If you have
questions before contributing, you can start by opening an issue on Github. 
