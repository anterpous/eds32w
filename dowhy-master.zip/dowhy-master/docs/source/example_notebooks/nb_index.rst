.. dowhy documentation file for jupyter notebooks, created by

.. toctree::
   :maxdepth: 2
   :caption: Getting Started
   
   dowhy_simple_example
   dowhy_confounder_example
   dowhy_estimation_methods
   dowhy-simple-iv-example 
   load_graph_example
   dowhy_causal_api
   do_sampler_demo

