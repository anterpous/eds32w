.. Advanced notebooks
   
.. toctree::
   :maxdepth: 2
   :caption: Advanced

   dowhy-conditional-treatment-effects
   dowhy_mediation_analysis.ipynb
   dowhy_demo_dummy_outcome_refuter.ipynb
   dowhy_multiple_treatments.ipynb
   dowhy_refuter_notebook

