.. Case Study notebooks

.. toctree::
   :maxdepth: 2
   :caption: Case Studies

   DoWhy-The Causal Story Behind Hotel Booking Cancellations
   dowhy_example_effect_of_memberrewards_program
   dowhy_ihdp_data_example
   dowhy_twins_example
   dowhy_lalonde_example
   dowhy_refutation_testing
   lalonde_pandas_api

